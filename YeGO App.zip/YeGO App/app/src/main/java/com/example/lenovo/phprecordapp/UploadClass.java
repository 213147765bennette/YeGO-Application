package com.example.lenovo.phprecordapp;

/**
 * Created by Lenovo on 2018-05-22.
 */

public class UploadClass {

    private String wordtoadd;
    private String wordClass;
    private String language;

    public UploadClass() {
    }

    public UploadClass(String wordtoadd, String wordClass, String language) {


        this.wordtoadd = wordtoadd;
        this.wordClass = wordClass;
        this.language = language;
    }

    public String getWordtoadd() {
        return wordtoadd;
    }

    public void setWordtoadd(String wordtoadd) {
        this.wordtoadd = wordtoadd;
    }

    public String getWordClass() {
        return wordClass;
    }

    public void setWordClass(String wordClass) {
        this.wordClass = wordClass;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
