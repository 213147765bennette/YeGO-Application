package com.example.lenovo.phprecordapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Signup extends AppCompatActivity {

    InputStream is=null;
    String result=null;
    String line=null;
    CheckBox myCheckbox;
    EditText edtFirst,edtLast,txtUsername, edtUser, edtPass, edtConfPass, edtEmail,edtPassword,edtConfirmpassword;

    DatabaseReference myClientinfo;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    String firstname ="";
    String surname ="";

    String username ="";
    String email = "";
    String password = "";
    String confirmPass = "";


    SaveUserDB saveUserDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);



        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        saveUserDB = new SaveUserDB(this);

        myClientinfo = FirebaseDatabase.getInstance().getReference("clientClass");


       // edtLast=(EditText)findViewById(R.id.edtlastname);

        txtUsername=(EditText)findViewById(R.id.edtUsername);
        edtEmail=(EditText)findViewById(R.id.edtEmail);
        edtPassword=(EditText)findViewById(R.id.edtPassword);
        edtConfirmpassword = (EditText)findViewById(R.id.edtconfirmsPasswrd);
        //edtCode=(EditText)findViewById(R.id.editText4);

        myCheckbox = (CheckBox)findViewById(R.id.terms);


        //firstname = edtFirst.getText().toString();
       // username = txtUsername.getText().toString();

        email = edtEmail.getText().toString();
        password = edtPassword.getText().toString();
        confirmPass = edtConfirmpassword.getText().toString();





    }

    public void CreateAccount(){

        if (txtUsername.getText().toString().length() == 0) {
            txtUsername.setError("Username name not entered");
            txtUsername.requestFocus();
        }else
        if (!edtEmail.getText().toString().contains("@")) {
            edtEmail.setError("Enter valid email address");
            edtEmail.requestFocus();
        }else
        if(edtPassword.getText().toString().length() < 4)
        {
            edtPassword.setError("Password must have four characters or more");
            edtPassword.requestFocus();
        }else
        if(edtConfirmpassword.getText().toString().compareTo(edtPassword.getText().toString())  !=0)
        {
            edtConfirmpassword.setError("The password don't match");
            edtConfirmpassword.requestFocus();

        }else
        if(myCheckbox.isChecked()){


            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

            //nameValuePairs.add(new BasicNameValuePair("firstname",edtFirst.getText().toString()));

            nameValuePairs.add(new BasicNameValuePair("username", txtUsername.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("email", edtEmail.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("password", edtPassword.getText().toString()));

            try {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://www.yego.africa/Register.php");
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
                Log.e("pass 1", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 1", e.toString());
                Toast.makeText(getApplicationContext(), "Connection Error,Please check your internet connection",
                        Toast.LENGTH_LONG).show();
            }

            try {
                BufferedReader reader = new BufferedReader
                        (new InputStreamReader(is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                result = sb.toString();
                Log.e("pass 2", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 2", e.toString());
            }

            try {
                JSONObject json_data = new JSONObject(result);

                String myString = json_data.getString("code");

                if(myString.equals("1"))
                {
                    Toast.makeText(this, "Account created", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(this, "Account was not created", Toast.LENGTH_LONG).show();
                }



            } catch (Exception e) {
                Log.e("Fail 3", e.toString());
            }

            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);




        }else{
            Toast.makeText(this,"Please note that you need to accept our terms and conditions first",Toast.LENGTH_LONG).show();
        }


    }


    public void signupNow(View view)
    {







        /**String id = myClientinfo.push().getKey();

        ClientClass clientClass = new  ClientClass(edtFirst.getText().toString(),edtLast.getText().toString()
                ,edtEmail.getText().toString(),  edtPassword.getText().toString(), edtConfirmpassword.getText().toString());


        myClientinfo.child(id).setValue(clientClass);


        saveUserDB.insertContent(edtFirst.getText().toString(),edtLast.getText().toString(),edtEmail.getText().toString(),edtPassword.getText().toString());
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);*/


    }




}
