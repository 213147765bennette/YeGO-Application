package com.example.lenovo.phprecordapp;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Lenovo on 2018-06-03.
 */

public class MyCustomAdapter extends ArrayAdapter{

    //private ArrayList<String> list = new ArrayList<String>();
    //private final Activity context;
    private String[] myArraylist;
   // public MediaRecorder recordedVoice;

    String result=null;
    String line=null;
    SaveToDictionaryModel saveToDictionaryModel;
    private String SERVER_URL = "http://www.yego.africa/";
     MediaPlayer mediaPlayer;
    public MediaRecorder recordedVoice;
    AlertDialog dialog;
    String username;
    ListView myView;
    TextView txtName;
    InputStream is=null;
    MainActivity mainActivity;
    String yourword ="";
    String language="";
    String wordclass="";
    String description="";
    String relatedWord ="";
    AlertDialog.Builder builder;
    TextView txtWord;
    String[] myList;
    LayoutInflater inflater;
    Button btnPlay;
    public Button record,play,stop;
    ArrayList<SaveToDictionaryModel> modelList;

    ArrayList<SaveToDictionaryModel> myModelList;
    ArrayAdapter<SaveToDictionaryModel> myAdapter;
    int pos;

    public int   newPosition;

    SaveToDictionaryModel[] list;

        Context context;



    public MyCustomAdapter(@NonNull Context context, SaveToDictionaryModel[] list) {
        super(context,R.layout.listvieitems,list);


        this.context=context;
        this.list = list;
    }

   /* public MyCustomAdapter(ArrayList<String> list, Context context) {
        this.list = list;
        this.context = context;
    }*/


    @Override
    public View getView(final int position,View view,ViewGroup parent) {


        inflater  = ((Activity)context).getLayoutInflater();

        //newPosition =position;
            View rowview = inflater.inflate(R.layout.listvieitems,null,true);

        txtName  = rowview.findViewById(R.id.textView23);
        txtWord = rowview.findViewById(R.id.textView24);

        txtWord.setText(list[position].getWordAdded());

        Button btnDetails = rowview.findViewById(R.id.button7);
       btnPlay = rowview.findViewById(R.id.button6);

        saveToDictionaryModel = new SaveToDictionaryModel();

        username=MainActivity.user_email;
        int myindex = username.indexOf('@');

        String myName = username.substring(0,myindex);
        txtName.setText("Added by: "+myName);



        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {


                builder = new AlertDialog.Builder(getContext());

                final View alertView = inflater.inflate(R.layout.dialog_universal_info,null);

                TextView word = alertView.findViewById(R.id.idword);
                TextView wordclass = alertView.findViewById(R.id.wordclass);
                TextView desc = alertView.findViewById(R.id.description);
                TextView lang = alertView.findViewById(R.id.language);

                word.setText("Word: "+list[position].getWordAdded());
                wordclass.setText("Word class: " +list[position].getWordClass());
                desc.setText("Description: "+list[position].getDescription());
                lang.setText("Language: "+list[position].getLanguage());


                builder.setView(alertView);
                dialog  = builder.create();
                dialog.show();

                Button btnOk = alertView.findViewById(R.id.okButton);

                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        dialog.dismiss();
                    }
                });



            }
        });



        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                stopPlaying();

                 recordedVoice = new MediaRecorder();

                 recordedVoice.setAudioSource(MediaRecorder.AudioSource.MIC);
                 recordedVoice.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                 recordedVoice.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
                 recordedVoice.setOutputFile(list[position].getRelatedWord());

                //RecordMyWord recordMyWord = new RecordMyWord();

                //String filePath = recordMyWord.getFilename();

                //Environment.getExternalStorageDirectory().getAbsolutePath()
               // recordedVoice.setOutputFile(filePath);

                 mediaPlayer  = new MediaPlayer();

               //final String path = ;
                String n=list[position].getRelatedWord();
             // Toast.makeText(getContext(), list[position].getRelatedWord().toString(),Toast.LENGTH_LONG).show();

                //Toast.makeText(getContext(), path,Toast.LENGTH_LONG).show();

                try{

                    //recordedVoice = new MediaRecorder();
                    //recordedVoice.setOutputFile(list[position].getRelatedWord());
                   //mediaPlayer.reset();
                    //  "/storage/emulated/0/voice_8538.mp3"


                    //String path = list[position].getRelatedWord();
                    //mediaPlayer.stop();
                    //myRecorder.reset();
                    //mediaPlayer.release();


                        mediaPlayer.setDataSource(SERVER_URL+""+n);
                        //mediaPlayer.setDataSource(path);
                        mediaPlayer.prepare();
                        mediaPlayer.start();


                    /**record.setEnabled(false);
                     stop.setEnabled(false);
                     play.setEnabled(true);*/

                    //Toast.makeText(getContext(),"Now Playing Audio",Toast.LENGTH_LONG).show();

                }catch(Exception e)
                {

                }

               // Toast.makeText(getContext(),list[position].getRelatedWord()+"", Toast.LENGTH_LONG).show();


               /** builder = new AlertDialog.Builder(getContext());
                builder.create();
                builder.setTitle("Now playing your word description");

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub





                    }
                });

                AlertDialog alert = builder.create();

                alert.show();*/


            }
        });


        return rowview;
    }

    private void stopPlaying() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }


}
