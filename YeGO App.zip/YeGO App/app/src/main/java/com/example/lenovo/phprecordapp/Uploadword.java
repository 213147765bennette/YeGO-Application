package com.example.lenovo.phprecordapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;

import java.io.InputStream;
import java.util.ArrayList;


public class Uploadword extends AppCompatActivity {


    RadioGroup radio_grp;

    Spinner sp,sp2;
    int pos;

    InputStream is=null;
    String result=null;
    String line=null;


    public static String word_toadd;
    public static String language;
    public static String word_class;
    public static String  phrase_selected;

    private static final int PICK_AUDIO = 100;

    private StorageReference mStorage;

    EditText etdWordtoAdd,edtxtDescription,etdRelatedword;
    String wordToAdd = "";
    String relatedWord = "";

    public ArrayList<String> publicListofWords;

    SaveToDictionaryModel SaveToDictionaryModel;


    ArrayList<String> languages;
    ArrayList<String> phrase = new ArrayList<String>();
    ArrayList<String> wordclass = new ArrayList<String>();

    ArrayAdapter<String> adapterLanguages;
    ArrayAdapter<String> adapterWordClass;
    ArrayAdapter<String> adapterPhrase;
    private FirebaseAuth mAuth;
    String selectedLanguage = "";
    String selectedWordclass ="";
    String selectedPhrase = "";

    //private SeekBar soundSeekBar;

    SaveUserDB saveUserDB;

    //String audioPath = "voiceRecording.3gp";
    ArrayList<SaveToDictionaryModel> myModelList;


    DatabaseReference myClientinfo;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uploadword);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        myClientinfo = FirebaseDatabase.getInstance().getReference("clientClass");

        progressDialog = new ProgressDialog(this);
       // myModelList = new ArrayList<S>();

        mAuth =  FirebaseAuth.getInstance();



        saveUserDB = new SaveUserDB(this);
        myModelList = new ArrayList<SaveToDictionaryModel>();

        sp = (Spinner)findViewById(R.id.spinner);
        sp2 = (Spinner)findViewById(R.id.spinner2);

        etdWordtoAdd = (EditText)findViewById(R.id.edtEmail);
       // edtxtDescription = (EditText)findViewById(R.id.editText2);

        wordToAdd = etdWordtoAdd.getText().toString();

        radio_grp = (RadioGroup) findViewById(R.id.radioGroup);

        languages  = new ArrayList<String>();
        languages.add("English");
        languages.add("Ndebele");
        languages.add("Sotho");
        languages.add("Tswana");
        languages.add("Swati");
        languages.add("Venda");
        languages.add("Venda");
        languages.add("Tswana");

        adapterLanguages = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_expandable_list_item_1,languages);
        sp.setAdapter(adapterLanguages);




        radio_grp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedId) {

                pos=radio_grp.indexOfChild(findViewById(checkedId));

                switch (pos)
                {
                    case 0 :

                        wordclass.add("Noun");
                        wordclass.add("Verb");
                        wordclass.add("Adjective");
                        wordclass.add("Adverb");
                        wordclass.add("Pronoun");
                        wordclass.add("Preposition");
                        wordclass.add("Conjunction");

                        adapterWordClass = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_expandable_list_item_1,wordclass);
                        sp2.setAdapter(adapterWordClass);

                        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                                selectedWordclass = wordclass.get(position);

                                //selectedPhrase = phrase.get(position);

                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });

                        break;
                    case 1 :


                        phrase.add("Absolute Phrase");
                        phrase.add("Appositive Phrase");
                        phrase.add("Gerund Phrase");
                        phrase.add("Infinitive Phrase");
                        phrase.add("Noun Phrase");
                        phrase.add("Participial Phrase");
                        phrase.add("Prepositional Phrase");

                        adapterPhrase = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_expandable_list_item_1,phrase);
                        sp2.setAdapter(adapterPhrase);

                        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                                selectedPhrase = phrase.get(position);

                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });

                        break;


                }


            }
        });


        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedLanguage = languages.get(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode== PICK_AUDIO)
        {
            Uri uri = data.getData();
            String x = getpath(uri);

            if (saveUserDB.insertAudio(x,1))
            {
                Toast.makeText(getApplicationContext(),"Successfull",Toast.LENGTH_LONG).show();

            }else
                {
                    Toast.makeText(getApplicationContext(),"Not Successfull",Toast.LENGTH_LONG).show();

                }
        }
    }

    private String getpath(Uri uri) {

        if (uri==null)return null;

        String[] projection = {MediaStore.Audio.Media.DATA};
        Cursor cursor = managedQuery(uri,projection,null,null,null);
        if (cursor!=null)
        {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }

        return  uri.getPath();
    }

    /** public  List<SaveToDictionaryModel> getData()
    {
        myModelList = new ArrayList<SaveToDictionaryModel>();

        myModelList.add(new SaveToDictionaryModel(wordToAdd,selectedWordclass,"Word Description",selectedLanguage));

       saveUserDB.insertContent(wordToAdd,selectedLanguage,selectedWordclass,"Molepo desc");

        return myModelList;

    }*/



    public void nextPage(View view)
    {

        //Intent intent = new Intent(this,RecordMyWord.class);
        //startActivity(intent);

        if (etdWordtoAdd.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "please make sure you complete all actions", Toast.LENGTH_LONG).show();

        } else {

            Intent intent = new Intent(this,RecordVoice.class);

            intent.putExtra("wordtoadd", etdWordtoAdd.getText().toString());
            intent.putExtra("wordclass",selectedWordclass);
            intent.putExtra("language",selectedLanguage);
            intent.putExtra("phrase",selectedPhrase);


            startActivity(intent);
        }




    }

  /*** public  void saveData(View view) {
        if (etdWordtoAdd.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "You can not save empty data, please make sure you complete all actions", Toast.LENGTH_LONG).show();

        } else {

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

            new  MainActivity();
            String user_name=MainActivity.user_email;
            nameValuePairs.add(new BasicNameValuePair("wordtoadd", etdWordtoAdd.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("wordclass", "Noun"));
            nameValuePairs.add(new BasicNameValuePair("language", "sepedi"));
            nameValuePairs.add(new BasicNameValuePair("phrase", "Noun phrase"));
            nameValuePairs.add(new BasicNameValuePair("username",user_name));
            // nameValuePairs.add(new BasicNameValuePair("recordedAudio",outputFile));


            try {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://www.yego.africa/Record.php");
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
                Log.e("pass 1", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 1", e.toString());
                Toast.makeText(getApplicationContext(), "Connection Error,Please Wait!!" + e.toString(),
                        Toast.LENGTH_LONG).show();
            }

            try {
                BufferedReader reader = new BufferedReader
                        (new InputStreamReader(is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                result = sb.toString();
                Log.e("pass 2", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 2", e.toString());
            }

            try {
                JSONObject json_data = new JSONObject(result);

                String myString = json_data.getString("code");

                Toast.makeText(this, myString, Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                Log.e("Fail 3", e.toString());
            }



        }
    }*/


}


