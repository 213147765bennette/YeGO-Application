package com.example.lenovo.phprecordapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

public class RecordMyWord extends AppCompatActivity {


    private static final int PICK_FILE_REQUEST1 = 4;
    private static final String TAG = "";
    int pos;
    private static final int PICK_FILE_REQUEST = 1;


    private String SERVER_URL = "http://www.yego.africa/up.php";

    File file;
    private static final String AUDIO_RECORDER_FOLDER = "MyRecordedVoice";
    private String selectedFilePath;

    InputStream is=null;
    String result=null;
    String line=null;


    public static String audio = "Record";

    EditText edtRelatedwrd,edtDesc;

    String wordtoadd="";

Dialog dialog;
    String fileName="";

    public int n = 10000;
    public MediaRecorder myRecorder;
    public Button record,play,stop;
    public static  String outputFile="";
    public int count = 0;

    Intent intent;


    public static String word_toadd;
    public static String language;
    public static String word_class;
    public static String  phrase_selected;

    private static final int PICK_AUDIO = 100;

    private StorageReference mStorage;

    EditText etdWordtoAdd,edtxtDescription,etdRelatedword;
    String wordToAdd = "";
    String relatedWord = "";
    String desc = "";


    public ArrayList<String> publicListofWords;

    SaveToDictionaryModel SaveToDictionaryModel;


    ArrayList<String>  languages  = new ArrayList<String>();
    ArrayList<String> phrase = new ArrayList<String>();
    ArrayList<String> wordclass = new ArrayList<String>();

    Spinner languageSpinner,WordSpinner;


    ArrayAdapter<String> adapterLanguages;
    ArrayAdapter<String> adapterWordClass;
    ArrayAdapter<String> adapterPhrase;
    private FirebaseAuth mAuth;
    String selectedLanguage = "";
    String selectedWordclass ="";
    String selectedPhrase = "";

    //private SeekBar soundSeekBar;

    SaveUserDB saveUserDB;

    //String audioPath = "voiceRecording.3gp";
    ArrayList<SaveToDictionaryModel> myModelList;


    DatabaseReference myClientinfo;

    private  static String user_name="";
    ProgressDialog progressDialog;
    Bitmap bm;
    String path;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_my_word);


        new  MainActivity();
        user_name  =MainActivity.user_email;


        languageSpinner = (Spinner)findViewById(R.id.spinner3);
        WordSpinner = (Spinner)findViewById(R.id.spinner4);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
       StrictMode.setThreadPolicy(policy);

        mStorage = FirebaseStorage.getInstance().getReference();

        record = (Button)findViewById(R.id.button2);
        stop = (Button)findViewById(R.id.button3);
        play = (Button)findViewById(R.id.button4);

        stop.setEnabled(false);
        play.setEnabled(false);

        Random generator = new Random();

        n = generator.nextInt(n);

        outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/voice_" +n + ".mp3";

        selectedFilePath = outputFile;
         //path = Environment.getExternalStorageDirectory().toString();
        myRecorder = new MediaRecorder();

        myRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        myRecorder.setOutputFile(outputFile);

        etdWordtoAdd = (EditText)findViewById(R.id.editText4);
        edtxtDescription = (EditText)findViewById(R.id.editText5);

        wordToAdd = etdWordtoAdd.getText().toString();

        desc  = edtxtDescription.getText().toString();


        languages.add("English");
        languages.add("Ndebele");
        languages.add("Sotho");
        languages.add("Tswana");
        languages.add("Swati");
        languages.add("Venda");
        languages.add("Venda");
        languages.add("Tswana");

        adapterLanguages = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,languages);
        languageSpinner.setAdapter(adapterLanguages);


        wordclass.add("Select");
        wordclass.add("Noun");
        wordclass.add("Verb");
        wordclass.add("Adjective");
        wordclass.add("Adverb");
        wordclass.add("Pronoun");
        wordclass.add("Preposition");
        wordclass.add("Conjunction");

        adapterWordClass = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_1,wordclass);
        WordSpinner.setAdapter(adapterWordClass);


        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedLanguage = languages.get(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        WordSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedWordclass = wordclass.get(position);


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etdWordtoAdd.getText().toString().isEmpty()|| edtxtDescription.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"Please complete all fields first",Toast.LENGTH_LONG).show();

                }else {

                    try {
                        myRecorder.prepare();
                        myRecorder.start();

                    } catch (IllegalStateException ixx) {


                    } catch (IOException ex) {

                    }

                    record.setEnabled(false);
                    stop.setEnabled(true);

                    Toast.makeText(getApplicationContext(),"You can now start to record your voice...",Toast.LENGTH_LONG).show();

                }



            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                myRecorder.stop();
                //myRecorder.reset();
                myRecorder.release();
                myRecorder = null;
                record.setEnabled(true);
                stop.setEnabled(false);
                play.setEnabled(true);

                Toast.makeText(getApplicationContext(), "Audio Recorder successfully", Toast.LENGTH_LONG).show();

                /** boolean duplicate = false;

                 if(outputFile.equals(audio)){

                     duplicate = true;
                 }


                 if(duplicate){

                     Toast.makeText(getApplicationContext(), "Audio Name Already Exists", Toast.LENGTH_LONG).show();



                     /**try{
                      //MediaPlayer mediaPlayer  = new MediaPlayer();
                      // mediaPlayer.setDataSource(outputFile);

                      }catch(IOException iox){

                      }


                 }else
                 {



                 }*/



            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //Toast.makeText(getApplicationContext(), getFilename(), Toast.LENGTH_LONG).show();


                //showFileChooser();

                MediaPlayer mediaPlayer  = new MediaPlayer();

                try{



                    //String recordFile = getFilename();
                    //outputFile = getFilename();
                    mediaPlayer.setDataSource(outputFile);
                    mediaPlayer.prepare();
                    mediaPlayer.start();

                    record.setEnabled(false);
                    stop.setEnabled(false);
                    play.setEnabled(true);

                    Toast.makeText(getApplicationContext(),"Playing Audio",Toast.LENGTH_LONG).show();

                }catch(Exception e)
                {

                }



            }
        });



        //edtRelatedwrd = (EditText)findViewById(R.id.editText2);
        //edtDesc = (EditText)findViewById(R.id.editText3);

        //relatedWord = edtRelatedwrd.getText().toString();
        //desc = edtDesc.getText().toString();


        myClientinfo = FirebaseDatabase.getInstance().getReference("clientClass");

        progressDialog = new ProgressDialog(this);
        // myModelList = new ArrayList<S>();

        mAuth =  FirebaseAuth.getInstance();

        saveUserDB = new SaveUserDB(this);
        myModelList = new ArrayList<SaveToDictionaryModel>();


       /** phrase.add("Absolute Phrase");
        phrase.add("Appositive Phrase");
        phrase.add("Gerund Phrase");
        phrase.add("Infinitive Phrase");
        phrase.add("Noun Phrase");
        phrase.add("Participial Phrase");
        phrase.add("Prepositional Phrase");

        adapterPhrase = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_expandable_list_item_1,phrase);
        sp2.setAdapter(adapterPhrase);

        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedPhrase = phrase.get(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/






    }
    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/mpeg");
        startActivityForResult(Intent.createChooser(intent, "Choose File to Upload.."), PICK_FILE_REQUEST1);
    }



   public String getFilename() {
        count++;
        /**Calendar c = Calendar.getInstance();
        System.out.println("Current time => " + c.getTime());
        Date createdTime = new Date();
        int seconds = c.get(Calendar.DATE);
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(c.getTime());

        Random generator = new Random();
        int n = 10000;
        n = generator.nextInt(n);


        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
        String currentDateTimeString = sdf.format(d);*/

        File folder = new File(Environment.getExternalStorageDirectory() +
                "/" + getResources()+"Yego Africa");
        boolean success = true;
        if (!folder.exists()) {
            success = folder.mkdirs();
        }
        if (success) {
            file = new File(folder, AUDIO_RECORDER_FOLDER);
            file.mkdir();
        }


        selectedFilePath = file.getAbsolutePath() + "/" + "Recording_" + n + ".mp3";
        Log.e("recorded_media_path", selectedFilePath);
        //messageText.setText(selectedFilePath);
        return (file.toString());
    }



    public void executeMultipartPost() throws Exception {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 75, bos);
            byte[] data = bos.toByteArray();
            HttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost("http://www.yego.africa/up.php");
                    //"http://10.0.2.2/cfc/iphoneWebservice.cfc?returnformat=json&amp;method=testUpload");
            ByteArrayBody bab = new ByteArrayBody(data, "voice_8538.mp3");
            // File file= new File("/mnt/sdcard/forest.png");
            // FileBody bin = new FileBody(file);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addPart("upfile", bab);

            HttpEntity entity = builder.build();
//
            postRequest.setEntity(entity);


            HttpResponse response = httpClient.execute(postRequest);
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    response.getEntity().getContent(), "UTF-8"));
            String sResponse;
            StringBuilder s = new StringBuilder();

            Toast.makeText(this,response.toString(),Toast.LENGTH_LONG).show();

            while ((sResponse = reader.readLine()) != null) {
                s = s.append(sResponse);
            }
            System.out.println("Response: " + s);
        } catch (Exception e) {
            // handle exception here
            Log.e(e.getClass().getName(), e.getMessage());
        }
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        if(requestCode == 10 && resultCode == RESULT_OK){

           /** progress = new ProgressDialog(RecordMyWord.this);
            progress.setTitle("Uploading");
            progress.setMessage("Please wait...");
            progress.show();*/

            /**Thread t = new Thread(new Runnable() {
                @Override
                public void run() {

                    File f  = new File(data.getStringExtra("/storage/emulated/0/voice_3864.mp3"));
                            //data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
                    String content_type  = getMimeType(f.getPath());

                    String file_path = f.getAbsolutePath();

                    OkHttpClient client =new OkHttpClient();

                    OkHttpClient.Builder builder=new OkHttpClient.Builder();


                    builder.connectTimeout(30, TimeUnit.SECONDS);
                    builder.readTimeout(30, TimeUnit.SECONDS);
                    builder.writeTimeout(30, TimeUnit.SECONDS);
                   // client = builder.build();
                    //Toast.makeText(getApplicationContext(),content_type, Toast.LENGTH_LONG).show();
                    client=builder.build();


                   RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);

                    RequestBody request_body = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("type",content_type)
                            .addFormDataPart("uploaded_file",file_path.substring(file_path.lastIndexOf("/")+1) ,file_body)
                            .build();

                    Request request = new Request.Builder()
                            .url("http://www.yego.africa/up.php")
                            .post(request_body)
                            .build();

                    Response response=null;
                    try {
                        response = client.newCall(request).execute();


                        if(!response.isSuccessful()){
                            throw new IOException("Error : "+response);
                        }

                        //progress.dismiss();


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    finally {

                        response.close();

                    }



                }
            });*/

           // t.start();




        }
    }

    private  String getMimeType(String path){

        String extension = MimeTypeMap.getFileExtensionFromUrl(path);

        return  MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
    }

   /* ProgressDialog prosi;
    public void Save(View view){

        prosi = new ProgressDialog(RecordMyWord.this);
        prosi.setTitle("Uploading");
        prosi.setMessage("Please wait...");


        if(etdWordtoAdd.getText().toString().isEmpty()||selectedWordclass.isEmpty()||selectedLanguage.isEmpty()||edtxtDescription.getText().toString().isEmpty()){


            Toast.makeText(getApplicationContext(), "please make sure you complete all actions", Toast.LENGTH_LONG).show();

        }else{

            prosi.show();

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {



                    *//** *//*

                    //"/storage/emulated/0/voice_3864.mp3"
                    File f  = new File(outputFile);
                    //data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
                    String content_type  = getMimeType(f.getPath());

                    String file_path = f.getAbsolutePath();

                    OkHttpClient client = new OkHttpClient();

                    OkHttpClient.Builder builder=new OkHttpClient.Builder();


                    builder.connectTimeout(30, TimeUnit.SECONDS);
                    builder.readTimeout(30, TimeUnit.SECONDS);
                    builder.writeTimeout(30, TimeUnit.SECONDS);
                    // client = builder.build();
                    //Toast.makeText(getApplicationContext(),content_type, Toast.LENGTH_LONG).show();
                    client=builder.build();


                    RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);

                    RequestBody request_body = new MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("type",content_type)
                            .addFormDataPart("uploaded_file",file_path.substring(file_path.lastIndexOf("/")+1) ,file_body)
                            .addFormDataPart("wordtoadd",etdWordtoAdd.getText().toString())
                            .addFormDataPart("wordclass",selectedWordclass+"")
                            .addFormDataPart("language",selectedLanguage+"")
                            .addFormDataPart("desc",edtxtDescription.getText().toString())
                            .addFormDataPart("username",user_name)
                            .build();

                    Request request = new Request.Builder()
                            .url("http://www.yego.africa/Record.php")
                            .post(request_body)
                            .build();
                    // Toast.makeText(getApplicationContext(),content_type, Toast.LENGTH_LONG).show();

                    Response response=null;
                    try {
                        response = client.newCall(request).execute();


                        if(!response.isSuccessful()){
                            throw new IOException("Error : "+response);
                        }

                        prosi.dismiss();


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    finally {

                        response.close();

                    }


                }
            });

            t.start();



        }

        //Intent intent = new Intent(this,Dictionary.class);
        //startActivity(intent);


        *//**new MaterialFilePicker()
         .withActivity(RecordMyWord.this)
         .withRequestCode(10)
         .start();*//*


        //int  myResults = uploadFile(Environment.getExternalStorageDirectory().getAbsolutePath() + "/voice_" +n + ".mp3");
       // Toast.makeText(this, ""+myResults, Toast.LENGTH_LONG).show();




       *//** if (etdWordtoAdd.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "please make sure you complete all actions", Toast.LENGTH_LONG).show();

        } else {

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

            new  MainActivity();
            String user_name=MainActivity.user_email;

            nameValuePairs.add(new BasicNameValuePair("wordtoadd",etdWordtoAdd.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("wordclass",selectedWordclass));
            nameValuePairs.add(new BasicNameValuePair("language", selectedLanguage));
            nameValuePairs.add(new BasicNameValuePair("desc", edtxtDescription.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("username",user_name));
            // nameValuePairs.add(new BasicNameValuePair("recordedAudio",outputFile));

            // nameValuePairs.add(new BasicNameValuePair("phrase", phrase));
            //nameValuePairs.add(new BasicNameValuePair("relatedword",outputFile));

            try {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://www.yego.africa/Record.php");
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
                Log.e("pass 1", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 1", e.toString());
                Toast.makeText(getApplicationContext(), "Connection Error,Please Wait!!" + e.toString(),
                        Toast.LENGTH_LONG).show();
            }

            try {
                BufferedReader reader = new BufferedReader
                        (new InputStreamReader(is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                result = sb.toString();
                Log.e("pass 2", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 2", e.toString());
            }

            try {
                JSONObject json_data = new JSONObject(result);

                String myString = json_data.getString("code");

                Toast.makeText(this, myString, Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                Log.e("Fail 3", e.toString());
            }
            //outputFile = getFilename();

            // String recordFile = getFilename();




        }*//*




    }*/




    public int uploadFile(final String selectedFilePath){

       /** prog = new ProgressDialog(RecordMyWord.this);
        prog.setTitle("Uploading");
        prog.setMessage("Please wait...");
        prog.show();*/

        int serverResponseCode = 0;

        HttpURLConnection connection;
        DataOutputStream dataOutputStream;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";


        int bytesRead,bytesAvailable,bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;
        File selectedFile = new File(selectedFilePath);


        String[] parts = selectedFilePath.split("/");
        final String fileName = parts[parts.length-1];
        Toast.makeText(this,fileName,Toast.LENGTH_SHORT).show();
        if (!selectedFile.isFile()){
            //dialog.dismiss();

            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    Toast.makeText(RecordMyWord.this, "Source File Doesn't Exist: " + selectedFilePath, Toast.LENGTH_SHORT).show();


                    //tvFileName.setText("Source File Doesn't Exist: " + selectedFilePath);
                }
            });
            return 0;
        }else{
            try{
                //https://dayisa-manje.000webhostapp.com/select.php  https://dayisa-manje.000webhostapp.com/up.php

                //https://www.yego.africa/up.php
                FileInputStream fileInputStream = new FileInputStream(selectedFile);
                URL url = new URL("https://cpanel.yego.africa/up.php");
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);//Allow Inputs
                connection.setDoOutput(true);//Allow Outputs
                connection.setUseCaches(false);//Don't use a cached Copy
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Connection", "Keep-Alive");
                connection.setRequestProperty("ENCTYPE", "multipart/form-data");
                connection.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                connection.setRequestProperty("uploaded_file",selectedFilePath);
                Toast.makeText(RecordMyWord.this, selectedFilePath, Toast.LENGTH_SHORT).show();

                //creating new dataoutputstream
                dataOutputStream = new DataOutputStream(connection.getOutputStream());

                //writing bytes to data outputstream
                dataOutputStream.writeBytes(twoHyphens + boundary + lineEnd);
                dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
                        + selectedFilePath + "\"" + lineEnd);

                dataOutputStream.writeBytes(lineEnd);

                //returns no. of bytes present in fileInputStream
                bytesAvailable = fileInputStream.available();
                //selecting the buffer size as minimum of available bytes or 1 MB
                bufferSize = Math.min(bytesAvailable,maxBufferSize);
                //setting the buffer as byte array of size of bufferSize
                buffer = new byte[bufferSize];

                //reads bytes from FileInputStream(from 0th index of buffer to buffersize)
                bytesRead = fileInputStream.read(buffer,0,bufferSize);

                //loop repeats till bytesRead = -1, i.e., no bytes are left to read
                while (bytesRead > 0){
                    //write the bytes read from inputstream
                    dataOutputStream.write(buffer,0,bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable,maxBufferSize);
                    bytesRead = fileInputStream.read(buffer,0,bufferSize);
                }

                dataOutputStream.writeBytes(lineEnd);
                dataOutputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                serverResponseCode = connection.getResponseCode();
                String serverResponseMessage = connection.getResponseMessage();

                Log.i(TAG, "Server Response is: " + serverResponseMessage + ": " + serverResponseCode);

                //response code of 200 indicates the server status OK
                if(serverResponseCode == 200){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //prog.dismiss();
                            Toast.makeText(RecordMyWord.this, "File Upload completed.", Toast.LENGTH_SHORT).show();

                            //tvFileName.setText("File Upload completed.\n\n You can see the uploaded file here: \n\n" + "http://coderefer.com/extras/uploads/"+ fileName);
                        }
                    });
                }

                //closing the input and output streams
                fileInputStream.close();
                dataOutputStream.flush();
                dataOutputStream.close();



            } catch (FileNotFoundException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(RecordMyWord.this,"File Not Found",Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Toast.makeText(RecordMyWord.this, "URL error!", Toast.LENGTH_SHORT).show();

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(RecordMyWord.this, "Cannot Read/Write File!", Toast.LENGTH_SHORT).show();
            }

            //Toast.makeText(RecordMyWord.this, serverResponseCode, Toast.LENGTH_SHORT).show();
           // dialog.dismiss();
            return serverResponseCode;
        }

    }

}
