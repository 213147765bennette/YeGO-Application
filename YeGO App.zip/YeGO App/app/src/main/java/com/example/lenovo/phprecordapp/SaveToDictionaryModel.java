package com.example.lenovo.phprecordapp;

/**
 * Created by Lenovo on 2018-05-10.
 */

public class SaveToDictionaryModel {

    public String wordAdded = "";
    public String wordClass = "";
    public String description = "";
    //private String relatedWord = "";
    public String language = "";
    public String relatedWord = "";
    public String person = "";

    public SaveToDictionaryModel() {
    }

    public SaveToDictionaryModel(String wordAdded, String wordClass, String description, String language, String relatedWord,String person) {
        this.wordAdded = wordAdded;
        this.wordClass = wordClass;
        this.description = description;
        this.language = language;
        this.relatedWord = relatedWord;
        this.person = person;
    }

    public SaveToDictionaryModel(String wordAdded, String wordClass, String description, String language, String relatedWord) {
        this.wordAdded = wordAdded;
        this.wordClass = wordClass;
        this.description = description;
        this.language = language;
        this.relatedWord = relatedWord;

    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getWordAdded() {
        return wordAdded;
    }

    public void setWordAdded(String wordAdded) {
        this.wordAdded = wordAdded;
    }

    public String getWordClass() {
        return wordClass;
    }

    public void setWordClass(String wordClass) {
        this.wordClass = wordClass;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRelatedWord() {
        return relatedWord;
    }

    public void setRelatedWord(String relatedWord) {
        this.relatedWord = relatedWord;
    }

    @Override
    public String toString() {
        return  wordAdded;
    }



}
