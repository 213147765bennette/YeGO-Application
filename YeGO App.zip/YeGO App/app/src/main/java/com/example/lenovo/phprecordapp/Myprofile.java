package com.example.lenovo.phprecordapp;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;

public class Myprofile extends AppCompatActivity implements View.OnClickListener {

    public static final int REQUEST_CODE_GALLERY = 0x1;

    public static final int REQUEST_CODE_TAKE_PICTURE = 0x2;
    public static final int REQUEST_CODE_CROP_IMAGE = 0x3;
    public static final String TAG = "General_Setting";
    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    private static final int PICK_FILE_REQUEST1 = 4;

    private static final int RESULT_LOAD_IMAGE = 1;

    Button imageButton;
    ImageView imageView4;

    private String selectedFilePath;
    String image_path;
    private File mFileTemp;
    ImageView myimage;
    Bitmap bitmap;
    String encodedImage;
    byte[] imageBytes;
    String upLoadServerUri = null;

    TextView name_surname,txtEmail,txtphone,txtPass;

    ListView myistview;
    String[] mynames = {"Welcome","The dictionary","YegoAfrica"};
    ArrayAdapter<String> myAdapter;
    ArrayList<String> myList;
    String result=null;
    String line=null;
    InputStream is=null;
    String firstname = "";
    String lastname = "";
    String email = "";
    String password = "";
    ArrayList<SaveToDictionaryModel> myModelList;
    Cursor cursor;
    SaveUserDB saveUserDB;

    //SaveToDictionaryModel saveToDictionaryModel;

    String yourword ="";
    String language="";
    String wordclass="";
    String description="";
    String relatedWord ="";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);

        new MainActivity();
        String mail=MainActivity.email_profile;
        String pass=MainActivity.pass_word;
        //String username=MainActivity.username;
        //String first=MainActivity.first_name;

       // imageButton = (Button)findViewById(R.id.button10);

        imageView4 = (ImageView)findViewById(R.id.imageView4) ;

       // imageButton.setOnClickListener(this);
        imageView4.setOnClickListener(this);

        //myimage = (ImageView)findViewById(R.id.imageView4);

        //txtEmail = (TextView)findViewById(R.id.user_email);
       // txtphone = (TextView)findViewById(R.id.phone);
        name_surname = (TextView)findViewById(R.id.name_surname);
       // txtPass = (TextView)findViewById(R.id.password);

        //txtEmail.setText(mail);
        //txtphone.setText(lastname);
        //txtPass.setText(pass);
        //name_surname.setText();


        /**myList = new ArrayList<String>();

        myList.add("Welcome");
        myList.add("The dictionary");
        myList.add("YegoAfrica");
        myList.add("Show me");*/

        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        myModelList = new ArrayList<SaveToDictionaryModel>();

        new MainActivity();
        String username=MainActivity.user_email;
        nameValuePairs.add(new BasicNameValuePair("username",username));
        //nameValuePairs.add(new BasicNameValuePair("pass_word", edtconfirmsPasswrd.getText().toString()));

       // Toast.makeText(getContext(),username,Toast.LENGTH_LONG).show();
       /* try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.yego.africa/myUploads.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
            Log.e("pass 1", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 1", e.toString());
            Toast.makeText(getApplicationContext(), "Connection Error,Please Wait!!" + e.toString(),
                    Toast.LENGTH_LONG).show();
        }

        try {
            BufferedReader reader = new BufferedReader
                    (new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
            Log.e("pass 2", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 2", e.toString());
        }


        try {
            JSONObject json_data = new JSONObject(result);


            JSONArray jsonMainNode = json_data.optJSONArray("list");
            //myModelList=new ArrayList<SaveToDictionaryModel>();

            SaveToDictionaryModel[] saveToDictionaryModel = new SaveToDictionaryModel[jsonMainNode.length()];

            for (int i = 0;i < jsonMainNode.length();i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);

                yourword = jsonChildNode.getString("d_Word");
                description = jsonChildNode.getString("d_Description");
                language = jsonChildNode.getString("d_Language");
                wordclass = jsonChildNode.getString("d_wordClass");
                relatedWord = jsonChildNode.getString("related_words");


                //saveToDictionaryModel[i] = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);
               //myModelList.add(saveToDictionaryModel[i]);


            }

            //MyCustomAdapter adapter = new MyCustomAdapter(this,myList);

            MyCustomAdapter adapter = new MyCustomAdapter(Myprofile.this,saveToDictionaryModel);
            myistview = (ListView)findViewById(R.id.myistview);
            myistview.setAdapter(adapter);


        } catch (Exception e) {
            Log.e("Fail 3", e.toString());
        }
*/


        //myAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,myList);

       // myistview.setAdapter(myAdapter);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.imageView4:
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent,RESULT_LOAD_IMAGE);
                break;
        }
    }
    public void changeImage(View view){
        onClick(view);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == RESULT_LOAD_IMAGE && resultCode==RESULT_OK && data !=null){

            Uri selectedImage = data.getData();
            imageView4.setImageURI(selectedImage);
        }
    }
}
