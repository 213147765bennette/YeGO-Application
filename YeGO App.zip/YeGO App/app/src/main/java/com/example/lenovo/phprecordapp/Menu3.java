package com.example.lenovo.phprecordapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Bennette on 2018-06-26.
 */

public class Menu3 extends Fragment {


    private Uri pickedPhotoForContactUri;
    private static final int PHOTO_SIZE = 128;
    private static final int ADD_PHOTO = 1337;

    MyCustomAdapter adapter;

    private String SERVER_URL = "http://www.yego.africa/";
    Button imageButton;
    ImageView imageView4;


    private static final int PICK_IMAGE = 100;
    AlertDialog alertDialog;


    TextView name_surname;

    ListView myistview;


    String result=null;
    String line=null;
    InputStream is=null;

    ArrayList<SaveToDictionaryModel> myModelList;

    String yourword ="";
    String language="";
    String wordclass="";
    String description="";
    String relatedWord ="";
    String personUploaded="";

    HttpClient httpclient;

    Uri imgaeUri;
    Bitmap bitmap;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        getActivity().setTitle("My Profile");

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        new MainActivity();
        String mail=MainActivity.email_profile;
        String pass=MainActivity.pass_word;
        //String username=MainActivity.username;
        //String first=MainActivity.first_name;

        imageView4 = view.findViewById(R.id.imageView4);

        imageButton = view.findViewById(R.id.button10);


        //bitmap = getBitmapFromURL(SERVER_URL+"Language/ateam.jpg");
        //imageView4.setImageBitmap(bitmap);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);


                /**pickedPhotoForContactUri = null;
                final List<Intent> cameraIntents = new ArrayList<Intent>();
                final Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File file = new File(Environment.getExternalStorageDirectory(), "Temp-photo");
                pickedPhotoForContactUri = Uri.fromFile(file);
                captureIntent.putExtra("outputX", PHOTO_SIZE);
                captureIntent.putExtra("outputY", PHOTO_SIZE);
                captureIntent.putExtra("aspectX", 0);
                captureIntent.putExtra("aspectY", 0);
                captureIntent.putExtra("scale", true);
                captureIntent.putExtra("return-data", false);
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, pickedPhotoForContactUri);
                cameraIntents.add(captureIntent);

                final Intent galleryIntent = new Intent();
                galleryIntent.setType("image/*");
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);

                final Intent chooserIntent = Intent.createChooser(galleryIntent, "Select source");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, cameraIntents.toArray(new Parcelable[]{}));

                startActivityForResult(chooserIntent, ADD_PHOTO);*/

                openGallery();





        }
        });




        name_surname = view.findViewById(R.id.name_surname);



        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        myModelList = new ArrayList<SaveToDictionaryModel>();

        new MainActivity();

        String username=MainActivity.user_email;
        int profileCount = username.lastIndexOf('@');
        String profileNameDisplay = username.substring(0,profileCount);
        name_surname.setText(profileNameDisplay);
        nameValuePairs.add(new BasicNameValuePair("username",username));
        //nameValuePairs.add(new BasicNameValuePair("pass_word", edtconfirmsPasswrd.getText().toString()));

        // Toast.makeText(getContext(),username,Toast.LENGTH_LONG).show();
        try {


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.yego.africa/myUploads.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();

            Log.e("pass 1", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 1", e.toString());
            Toast.makeText(getActivity(), "Connection Error,Please Wait!!" +" Make sure you have fast internet connection",
                    Toast.LENGTH_LONG).show();
        }

        try {
            BufferedReader reader = new BufferedReader
                    (new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
            Log.e("pass 2", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 2", e.toString());
        }


        try {




            JSONObject json_data = new JSONObject(result);

            JSONArray jsonMainNode = json_data.optJSONArray("list");
            myModelList=new ArrayList<SaveToDictionaryModel>();

            SaveToDictionaryModel[] saveToDictionaryModel = new SaveToDictionaryModel[jsonMainNode.length()];

            for (int i = 0;i < jsonMainNode.length();i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);

                yourword = jsonChildNode.getString("d_Word");
                description = jsonChildNode.getString("d_Description");
                language = jsonChildNode.getString("d_Language");
                wordclass = jsonChildNode.getString("d_wordClass");
                relatedWord = jsonChildNode.getString("related_words");
                //personUploaded = jsonChildNode.getString("a_email");

                saveToDictionaryModel[i ] = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);
                myModelList.add(saveToDictionaryModel[i]);

            }




            //MyCustomAdapter adapter = new MyCustomAdapter(this,myList);

            adapter = new MyCustomAdapter(getActivity(),saveToDictionaryModel);
            myistview = view.findViewById(R.id.myistview);
            myistview.setAdapter(adapter);

            if(adapter.getCount()==0){

                Toast.makeText(getActivity().getApplicationContext(),"You have not uploaded anything yet. Please upload first",Toast.LENGTH_LONG).show();


            }





        } catch (Exception e) {
            Log.e("Fail 3", e.toString());
        }



        ProgressDialog progressDialog = WelcomeScreen.progressDialog;


            progressDialog.dismiss();







    }




    private void openGallery(){

        Intent gallery = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        startActivityForResult(gallery,PICK_IMAGE);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && requestCode==PICK_IMAGE ){

            imgaeUri = data.getData();

            imageView4.setImageURI(imgaeUri);

        }

    }




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.activity_myprofile,container,false);

    }






    /**public Bitmap getBitmapFromURL(String src){

        try{

            URL   = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            InputStream input=connection.getInputStream();
            Bitmap myBitmap=BitmapFactory.decodeStream(input);
            return myBitmap;

        }catch (Exception exx){

            exx.printStackTrace();
            return null;
        }

    }*/



}
