package com.example.lenovo.phprecordapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Lenovo on 2018-05-10.
 */

public class SaveUserDB extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Dictionary.db";
    public static final String CLIENT_TABLE_NAME = "voicerecorder";

    public static final String CLINET_PROFILE_TABLE = "clientprofile";

    public static final String CLINET_AUDIO_TABLE = "clientAudio";

    public static final String CLIENT_COLUMN_ID = "_id";
    public static final String CLIENT_COLUMN_YOURWORD= "yourword";
    public static final String CLIENT_COLUMN_LANGUAGE = "language";
    public static final String CLIENT_COLUMN_WORDCLASS = "wordclass";
    public static final String CLIENT_COLUMN_DESCRIPTION = "description";


    public SaveUserDB(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(

                "create table voicerecorder " +
                        "(_id integer primary key, yourword text,language text,wordclass text,description text)"

        );

        db.execSQL(

                "create table clientprofile " +
                        "(_id integer primary key, firstname text,lastname text,email text,password text)"

        );

        db.execSQL(

                "create table clientAudio " +
                        "(_id integer primary key, audio mp3 not null)"

        );


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS voicerecorder");

        db.execSQL("DROP TABLE IF EXIST clientprofile");

        db.execSQL("DROP TABLE IF EXIST clientAudio");

        onCreate(db);

    }

    public boolean insertContent (String firstname,String lastname,String email,String passsword) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("firstname", firstname);
        contentValues.put("lastname", lastname);
        contentValues.put("email", email);
        contentValues.put("password", passsword);

        db.insert(CLINET_PROFILE_TABLE, null, contentValues);
        return true;
    }

    public boolean insertAudio(String x, Integer i)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        try{
            FileInputStream fs = new FileInputStream(x);
            byte[] audiobyte = new byte[fs.available()];
            fs.read();

            contentValues.put("id",i);
            contentValues.put("mp3",audiobyte);

            db.insert(CLINET_AUDIO_TABLE,null,contentValues);

            fs.close();

            return  true;

        }catch (IOException e){
            e.printStackTrace();
            return  false;
        }

    }

    public boolean insertArrayObject (ArrayList<SaveToDictionaryModel> myDataList) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        for(int k=0; k<myDataList.size(); k++)
        {
            String yourword = myDataList.get(k).getWordAdded();
            String language = myDataList.get(k).getLanguage();
            String wordclass = myDataList.get(k).getWordClass();
            String description = myDataList.get(k).getDescription();

            contentValues.put("yourword", yourword);
            contentValues.put("language", language);
            contentValues.put("wordclass", wordclass);
            contentValues.put("description", description);
        }


        db.insert(CLIENT_TABLE_NAME, null, contentValues);
        return true;
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from voicerecorder ", null );
        return res;
    }

    public Cursor getclientData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from clientprofile ", null );
        return res;
    }
}
