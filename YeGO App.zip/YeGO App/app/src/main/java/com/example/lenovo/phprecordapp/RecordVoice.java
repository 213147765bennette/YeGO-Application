package com.example.lenovo.phprecordapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

public class RecordVoice extends AppCompatActivity {
    InputStream is=null;
    String result=null;
    String line=null;

    String relatedWord = "";
    String desc = "";

    public static String audio = "Record";

    EditText edtRelatedwrd,edtDesc;

    String wordtoadd="";
    String wordclass="";
    String language ="";
    String phrase = "";

    String fileName="";

    public int n = 10000;
    public MediaRecorder myRecorder;
    public Button record,play,stop;
    public static  String outputFile="";
    public int count = 0;

    Intent intent;
    private StorageReference mStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_voice);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        mStorage = FirebaseStorage.getInstance().getReference();

        record = (Button)findViewById(R.id.button2);
        stop = (Button)findViewById(R.id.button3);
        play = (Button)findViewById(R.id.button4);

        stop.setEnabled(false);
        play.setEnabled(false);



        //outputFile = Environment.getExternalStorageDirectory().getAbsolutePath()+audioPath;

        //Date date = new Date();
         //SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d HH:mm:ss");
        // String Mydate = sdf.format(date);
       // SimpleDateFormat timeStampFormat = new SimpleDateFormat(
               // "yyyy-MM-dd-HH.mm.ss");
        //fileName = "audio_" + sdf.format(date)
               // + ".3gp";

       // outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() +"/voice_" +".mp3";


        Random generator = new Random();

        n = generator.nextInt(n);

        outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/voice_" +n + ".mp3";


        myRecorder = new MediaRecorder();

        myRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        myRecorder.setOutputFile(outputFile);



        edtRelatedwrd = (EditText)findViewById(R.id.edtconfirmsPasswrd);
        edtDesc = (EditText)findViewById(R.id.editText3);

        relatedWord = edtRelatedwrd.getText().toString();
        desc = edtDesc.getText().toString();



        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtRelatedwrd.getText().toString().isEmpty()|| edtDesc.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"Please complete all fields first",Toast.LENGTH_LONG).show();

                }else {

                    try {
                        myRecorder.prepare();
                        myRecorder.start();

                    } catch (IllegalStateException ixx) {


                    } catch (IOException ex) {

                    }

                    record.setEnabled(false);
                    stop.setEnabled(true);

                    Toast.makeText(getApplicationContext(),"You can now start to record your voice...",Toast.LENGTH_LONG).show();

                }



            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                boolean duplicate = false;

                    if(outputFile.equals(audio)){

                        duplicate = true;
                    }


               if(duplicate){

                   Toast.makeText(getApplicationContext(), "Audio Name Already Exists", Toast.LENGTH_LONG).show();



                       /**try{
                           //MediaPlayer mediaPlayer  = new MediaPlayer();
                          // mediaPlayer.setDataSource(outputFile);

                       }catch(IOException iox){

                       }*/


               }else
                   {


                       myRecorder.stop();
                       myRecorder.reset();
                       myRecorder.release();
                       myRecorder = null;

                       Toast.makeText(getApplicationContext(), "Audio Recorder successfully", Toast.LENGTH_LONG).show();
                   }



            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                MediaPlayer mediaPlayer  = new MediaPlayer();

                try{


                    mediaPlayer.setDataSource(outputFile);
                    mediaPlayer.prepare();
                    mediaPlayer.start();

                    record.setEnabled(false);
                    stop.setEnabled(false);
                    play.setEnabled(true);

                    Toast.makeText(getApplicationContext(),"Playing Audio",Toast.LENGTH_LONG).show();

                }catch(IOException e)
                {

                }



            }
        });





        Intent intent = getIntent();



        wordtoadd =(String) intent.getSerializableExtra("wordtoadd");
        wordclass =(String) intent.getSerializableExtra("wordclass");
        language =(String) intent.getSerializableExtra("language");
        phrase =(String) intent.getSerializableExtra("phrase");


    }

    public  void saveData(View view) {

        if(edtRelatedwrd.getText().toString().isEmpty() ||edtDesc.getText().toString().isEmpty() )
        {
            Toast.makeText(getApplicationContext(), "please make sure you complete all fields", Toast.LENGTH_LONG).show();

        }else
            {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                new  MainActivity();
                String user_name=MainActivity.user_email;

                nameValuePairs.add(new BasicNameValuePair("wordtoadd",wordtoadd));
                nameValuePairs.add(new BasicNameValuePair("wordclass",wordclass));
                nameValuePairs.add(new BasicNameValuePair("language", language));
                nameValuePairs.add(new BasicNameValuePair("phrase", phrase));

                nameValuePairs.add(new BasicNameValuePair("relatedword",edtRelatedwrd.getText().toString()));
                nameValuePairs.add(new BasicNameValuePair("desc", edtDesc.getText().toString()));


                nameValuePairs.add(new BasicNameValuePair("username",user_name));

                nameValuePairs.add(new BasicNameValuePair("recordedAudio",outputFile));


                try {
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost("http://www.yego.africa/Record.php");
                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();
                    is = entity.getContent();
                    Log.e("pass 1", "connection success ");
                } catch (Exception e) {
                    Log.e("Fail 1", e.toString());
                    Toast.makeText(getApplicationContext(), "Connection Error,Please Wait!!" + e.toString(),
                            Toast.LENGTH_LONG).show();
                }

                try {
                    BufferedReader reader = new BufferedReader
                            (new InputStreamReader(is, "iso-8859-1"), 8);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    is.close();
                    result = sb.toString();
                    Log.e("pass 2", "connection success ");
                } catch (Exception e) {
                    Log.e("Fail 2", e.toString());
                }

                try {
                    JSONObject json_data = new JSONObject(result);

                    String myString = json_data.getString("code");

                    Toast.makeText(this, myString, Toast.LENGTH_LONG).show();

                } catch (Exception e) {
                    Log.e("Fail 3", e.toString());
                }

                Intent intent = new Intent(this,Dictionary.class);
                intent.putExtra("path",outputFile);
                startActivity(intent);

            }





    }


    public  String returnVoice()
    {
        Random generator = new Random();

        n = generator.nextInt(n);

        String myVoice = Environment.getExternalStorageDirectory().getAbsolutePath() + "/voice_" +n + ".mp3";

        return  myVoice;
    }
}
