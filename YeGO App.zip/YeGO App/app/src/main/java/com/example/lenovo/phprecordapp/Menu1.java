package com.example.lenovo.phprecordapp;

import android.app.Dialog;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Lenovo on 2018-06-26.
 */

public class Menu1 extends android.support.v4.app.Fragment {

    private MediaPlayer mediaPlayer;
    public MediaRecorder myRecorder;
    DictionayCustomAdapter adapter;
    InputStream is=null;

    ArrayList<SaveToDictionaryModel> myList = new ArrayList<SaveToDictionaryModel>();
    ArrayAdapter<SaveToDictionaryModel> myAdapter;

    String wordToAdd = "";
    String selectedwordclass = "";
    String desc = "";
    private String SERVER_URL = "http://www.yego.africa/";
    String yourword ="";
    String language="";
    String wordclass="";
    String description="";
    String relatedWord ="";

    String result=null;
    String line=null;

    SearchView searchView;
    String personUploaded ="";
    Dialog myDialog;

    String addTolist = "";

    Cursor cursor;
    String voicepath;

    Uploadword uploadword;
    File[] myFiles;
    int pos;
    SaveToDictionaryModel saveToDictionaryModel;

    ArrayList<SaveToDictionaryModel> myModelList;

    ArrayList<String> myWords;

    Menu menu;

    SaveToDictionaryModel[] list;

    ListView myView;
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Dictionary");

        myView = view.findViewById(R.id.myListView);


        saveToDictionaryModel = new SaveToDictionaryModel();

        myModelList = new ArrayList<SaveToDictionaryModel>();

        // cursor = saveUserDB.getData();

        /**if(cursor.moveToFirst()) {

         yourword = cursor.getString(1);
         language = cursor.getString(2);
         wordclass = cursor.getString(3);
         description = cursor.getString(4);

         saveToDictionaryModel = new SaveToDictionaryModel();

         saveToDictionaryModel.setWordAdded(yourword);
         saveToDictionaryModel.setLanguage(language);
         saveToDictionaryModel.setWordClass(wordclass);
         saveToDictionaryModel.setDescription(description);

         myModelList.add(saveToDictionaryModel);

         cursor.moveToNext();
         }*/
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();


        //nameValuePairs.add(new BasicNameValuePair("username", edtEmail.getText().toString()));
        //nameValuePairs.add(new BasicNameValuePair("pass_word", edtconfirmsPasswrd.getText().toString()));

        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.yego.africa/read.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
            Log.e("pass 1", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 1", e.toString());
            Toast.makeText(getContext(), "Connection Error,Please check your internet connection!!",
                    Toast.LENGTH_LONG).show();
        }

        try {
            BufferedReader reader = new BufferedReader
                    (new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
            Log.e("pass 2", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 2", e.toString());
        }

        try {
            JSONObject json_data = new JSONObject(result);

            String test="";
            JSONArray jsonMainNode = json_data.optJSONArray("list");
            SaveToDictionaryModel[] saveToDictionaryModel = new SaveToDictionaryModel[jsonMainNode.length()];
            for (int i = 0;i < jsonMainNode.length();i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);

                yourword = jsonChildNode.getString("d_Word");
                description = jsonChildNode.getString("d_Description");
                language = jsonChildNode.getString("d_Language");
                wordclass = jsonChildNode.getString("d_wordClass");
                relatedWord = jsonChildNode.getString("related_words");
                personUploaded = jsonChildNode.getString("a_email");
              //  test = jsonChildNode.getString("take");
                // saveToDictionaryModel = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);




                saveToDictionaryModel[i] = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord,personUploaded);
                myModelList.add(saveToDictionaryModel[i]);



            }



            adapter  = new DictionayCustomAdapter(getActivity(),saveToDictionaryModel);
            //myistview = (ListView)findViewById(R.id.myistview);
            myView.setAdapter(adapter);
            //Toast.makeText(getActivity(),test,Toast.LENGTH_LONG).show();
            //Toast.makeText(this, first_name+" "+email_profile+" "+last_name, Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.e("Fail 3", e.toString());
        }



        if(myModelList.isEmpty())
        {
            Toast.makeText(getContext(),"The dictionary is empty please go back and upload your word to the dictionary first", Toast.LENGTH_LONG).show();

        }


        menu = view.findViewById(R.menu.welcome_screen);
    }




    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View rootview = inflater.inflate(R.layout.activity_dictionary,container,false);

       /**MenuItem item = menu.findItem(R.id.action_search);
        searchView = (SearchView)item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });*/


        return rootview;
    }

   /** @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.welcome_screen,menu);
        MenuItem item = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }*/




}
