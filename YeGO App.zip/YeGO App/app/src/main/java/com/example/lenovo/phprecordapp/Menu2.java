package com.example.lenovo.phprecordapp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by Lenovo on 2018-06-26.
 */

public class Menu2 extends Fragment {

    private static final int PICK_FILE_REQUEST1 = 4;
    private static final String TAG = "";
    int pos;
    private static final int PICK_FILE_REQUEST = 1;


    Button button8;
    private String SERVER_URL = "http://www.yego.africa/up.php";

    File file;
    private static final String AUDIO_RECORDER_FOLDER = "MyRecordedVoice";
    private String selectedFilePath;

    InputStream is=null;
    String result=null;
    String line=null;


    public static String audio = "Record";

    EditText edtRelatedwrd,edtDesc;

    String wordtoadd="";

    Dialog dialog;
    String fileName="";

    public int n = 10000;
    public MediaRecorder myRecorder;
    public Button record,play,stop;
    public static  String outputFile="";
    public int count = 0;

    Intent intent;


    public static String word_toadd;
    public static String language;
    public static String word_class;
    public static String  phrase_selected;

    private static final int PICK_AUDIO = 100;

    private StorageReference mStorage;

    EditText etdWordtoAdd,edtxtDescription,etdRelatedword;
    String wordToAdd = "";
    String relatedWord = "";
    String desc = "";


    public ArrayList<String> publicListofWords;

    SaveToDictionaryModel SaveToDictionaryModel;


    ArrayList<String>  languages  = new ArrayList<String>();
    ArrayList<String> phrase = new ArrayList<String>();
    ArrayList<String> wordclass = new ArrayList<String>();

    Spinner languageSpinner,WordSpinner;


    ArrayAdapter<String> adapterLanguages;
    ArrayAdapter<String> adapterWordClass;
    ArrayAdapter<String> adapterPhrase;
    private FirebaseAuth mAuth;
    String selectedLanguage = "";
    String selectedWordclass ="";
    String selectedPhrase = "";

    //private SeekBar soundSeekBar;

    SaveUserDB saveUserDB;

    //String audioPath = "voiceRecording.3gp";
    ArrayList<SaveToDictionaryModel> myModelList;


    DatabaseReference myClientinfo;

    private  static String user_name="";
    ProgressDialog progressDialog;
    Bitmap bm;
    String path;
    ProgressDialog prosi;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Upload");

        button8 = view.findViewById(R.id.button8);

        new  MainActivity();
        user_name  =MainActivity.user_email;


        languageSpinner = view.findViewById(R.id.spinner3);
        WordSpinner = view.findViewById(R.id.spinner4);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        mStorage = FirebaseStorage.getInstance().getReference();

        record = view.findViewById(R.id.button2);
        stop = view.findViewById(R.id.button3);
        play = view.findViewById(R.id.button4);

        stop.setEnabled(false);
        play.setEnabled(false);

        Random generator = new Random();

        n = generator.nextInt(n);

        outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/voice_" +n + ".mp3";

        selectedFilePath = outputFile;
        //path = Environment.getExternalStorageDirectory().toString();
        myRecorder = new MediaRecorder();

        myRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        myRecorder.setOutputFile(outputFile);

        etdWordtoAdd = view.findViewById(R.id.editText4);
        edtxtDescription = view.findViewById(R.id.editText5);

        wordToAdd = etdWordtoAdd.getText().toString();

        desc  = edtxtDescription.getText().toString();


        languages.add("English");
        languages.add("Ndebele");
        languages.add("Sotho");
        languages.add("Tswana");
        languages.add("Swati");
        languages.add("Venda");
        languages.add("Venda");
        languages.add("Tswana");

        adapterLanguages = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_expandable_list_item_1,languages);
        languageSpinner.setAdapter(adapterLanguages);


        wordclass.add("Select");
        wordclass.add("Noun");
        wordclass.add("Verb");
        wordclass.add("Adjective");
        wordclass.add("Adverb");
        wordclass.add("Pronoun");
        wordclass.add("Preposition");
        wordclass.add("Conjunction");

        adapterWordClass = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_expandable_list_item_1,wordclass);
        WordSpinner.setAdapter(adapterWordClass);


        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedLanguage = languages.get(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        WordSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedWordclass = wordclass.get(position);


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etdWordtoAdd.getText().toString().isEmpty()|| edtxtDescription.getText().toString().isEmpty() || selectedWordclass.isEmpty() || selectedLanguage.isEmpty())
                {
                    Toast.makeText(getActivity(),"Please complete all fields first",Toast.LENGTH_LONG).show();

                }else {

                    try {
                        myRecorder.prepare();
                        myRecorder.start();

                    } catch (IllegalStateException ixx) {


                    } catch (IOException ex) {

                    }

                    record.setEnabled(false);
                    stop.setEnabled(true);

                    Toast.makeText(getActivity(),"You can now start to record your voice...",Toast.LENGTH_LONG).show();

                }



            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                myRecorder.stop();
                //myRecorder.reset();
                myRecorder.release();
                myRecorder = null;
                record.setEnabled(true);
                stop.setEnabled(false);
                play.setEnabled(true);

                Toast.makeText(getActivity(), "Audio Recorder successfully", Toast.LENGTH_LONG).show();

                /** boolean duplicate = false;

                 if(outputFile.equals(audio)){

                 duplicate = true;
                 }


                 if(duplicate){

                 Toast.makeText(getApplicationContext(), "Audio Name Already Exists", Toast.LENGTH_LONG).show();



                 /**try{
                 //MediaPlayer mediaPlayer  = new MediaPlayer();
                 // mediaPlayer.setDataSource(outputFile);

                 }catch(IOException iox){

                 }


                 }else
                 {



                 }*/



            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //Toast.makeText(getApplicationContext(), getFilename(), Toast.LENGTH_LONG).show();


                //showFileChooser();

                MediaPlayer mediaPlayer  = new MediaPlayer();

                try{




                    //String recordFile = getFilename();
                    //outputFile = getFilename();
                    mediaPlayer.setDataSource(outputFile);
                    mediaPlayer.prepare();
                    mediaPlayer.start();

                    record.setEnabled(false);
                    stop.setEnabled(false);
                    play.setEnabled(true);

                    Toast.makeText(getActivity(),"Playing Audio",Toast.LENGTH_LONG).show();

                }catch(Exception e)
                {

                }



            }
        });



        //edtRelatedwrd = (EditText)findViewById(R.id.editText2);
        //edtDesc = (EditText)findViewById(R.id.editText3);

        //relatedWord = edtRelatedwrd.getText().toString();
        //desc = edtDesc.getText().toString();


        myClientinfo = FirebaseDatabase.getInstance().getReference("clientClass");

        progressDialog = new ProgressDialog(getActivity());
        // myModelList = new ArrayList<S>();

        mAuth =  FirebaseAuth.getInstance();

        saveUserDB = new SaveUserDB(getActivity());
        myModelList = new ArrayList<SaveToDictionaryModel>();



        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prosi = new ProgressDialog(getActivity());
                prosi.setTitle("Uploading");
                prosi.setMessage("Please wait...");


                if (outputFile==null|| etdWordtoAdd.getText().toString().isEmpty() || selectedLanguage.isEmpty() ||
                        edtxtDescription.getText().toString().isEmpty() || selectedWordclass.isEmpty() ||selectedFilePath.isEmpty()) {
                    Toast.makeText(getActivity(), "please make sure you complete all the fields and record your explanation", Toast.LENGTH_LONG).show();

                } else {



                    Thread t = new Thread(new Runnable() {
                        @Override
                        public void run() {



                            /** */

                            //"/storage/emulated/0/voice_3864.mp3"
                            File f  = new File(outputFile);
                            //data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
                            String content_type  = getMimeType(f.getPath());

                            String file_path = f.getAbsolutePath();

                            OkHttpClient client =new OkHttpClient();

                            OkHttpClient.Builder builder=new OkHttpClient.Builder();


                            builder.connectTimeout(30, TimeUnit.SECONDS);
                            builder.readTimeout(30, TimeUnit.SECONDS);
                            builder.writeTimeout(30, TimeUnit.SECONDS);
                            // client = builder.build();
                            //Toast.makeText(getApplicationContext(),content_type, Toast.LENGTH_LONG).show();
                            client=builder.build();


                            RequestBody file_body = RequestBody.create(MediaType.parse(content_type),f);

                            RequestBody request_body = new MultipartBody.Builder()
                                    .setType(MultipartBody.FORM)
                                    .addFormDataPart("type",content_type)
                                    .addFormDataPart("uploaded_file",file_path.substring(file_path.lastIndexOf("/")+1) ,file_body)
                                    .addFormDataPart("wordtoadd",etdWordtoAdd.getText().toString())
                                    .addFormDataPart("wordclass",selectedWordclass+"")
                                    .addFormDataPart("language",selectedLanguage+"")
                                    .addFormDataPart("desc",edtxtDescription.getText().toString())
                                    .addFormDataPart("username",user_name)
                                    .build();

                            Request request = new Request.Builder()
                                    .url("http://www.yego.africa/Record.php")
                                    .post(request_body)
                                    .build();
                            //
                            Response response=null;
                            try {
                                response = client.newCall(request).execute();


                                if(!response.isSuccessful()){
                                    throw new IOException("Error : "+response);
                                }

                                prosi.dismiss();


                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            finally {

                               // response.close();

                            }


                        }
                    });

                    t.start();

                    Toast.makeText(getActivity(),"Thank you for uploading, please navigate to Dictionary", Toast.LENGTH_LONG).show();



                }



                //Intent intent = new Intent(getContext(),Menu1.class);
               //startActivity(intent);

            }
        });

    }

    private  String getMimeType(String path){

        String extension = MimeTypeMap.getFileExtensionFromUrl(path);

        return  MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
    }



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_record_my_word,container,false);
    }


}
