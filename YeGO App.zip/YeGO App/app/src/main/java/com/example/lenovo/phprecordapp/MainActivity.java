package com.example.lenovo.phprecordapp;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class MainActivity extends AppCompatActivity {

    RelativeLayout rootlayout;


    public static String first_name;
    public static String email_profile;
    public static String last_name;
    public static String  pass_word;

    CheckBox myCheckbox,checkBox2;
    private int VOICE_PERMISSION=1;
    InputStream is=null;
    String result=null;
    String line=null;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    ProgressBar mprogress;

    public static    String user_email="";

    ProgressDialog progressDialog;
    DatabaseReference myClientinfo;

    EditText edtEmails,edtconfirmsPasswrds;
    String email="";
    String password = "";

    Cursor cursor;
    SaveUserDB saveuserDb;

    String firstname ="";
    String lastname = "";
    String DBemail = "";
    String DBpassword = "";

    Button btnRegister;


    MaterialEditText txtUsername,edtEmail,edtPassword,edtConfirmpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        saveuserDb = new SaveUserDB(this);

        cursor = saveuserDb.getclientData();


        mAuth = FirebaseAuth.getInstance();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d("My TAG", "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d("My TAG 2", "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };
        //mprogress=(ProgressBar)findViewById(R.id.progressBar2);
        //mprogress.setVisibility(View.GONE);

        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                               .setDefaultFontPath("fonts/Arkip_font.tff")
                                .setFontAttrId(R.attr.fontPath)
                                .build());


        rootlayout = (RelativeLayout)findViewById(R.id.rootlayout);


        btnRegister = (Button)findViewById(R.id.register);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                registerUserAccount();
            }
        });

        myCheckbox = (CheckBox)findViewById(R.id.remember);

        myCheckbox.setChecked(true);




        edtEmails = (EditText)findViewById(R.id.edtEmail);
        edtconfirmsPasswrds = (EditText)findViewById(R.id.edtconfirmsPasswrd);

        myClientinfo = FirebaseDatabase.getInstance().getReference("clientClass");

        password = edtconfirmsPasswrds.getText().toString();
        email = edtEmails.getText().toString();

        if(cursor.moveToFirst())
        {


            firstname = cursor.getString(1);
            lastname = cursor.getString(2);
            DBemail = cursor.getString(3);
            DBpassword = cursor.getString(4);

            cursor.moveToNext();

        }


        if(edtconfirmsPasswrds.getText().toString().length() <4)
        {
            edtconfirmsPasswrds.setError("Enter valid password");
            edtconfirmsPasswrds.requestFocus();
        }

        if (!edtEmails.getText().toString().contains("@")) {
            edtEmails.setError("Enter valid email address");
            edtEmails.requestFocus();
        }



        if(ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)





        /**  Manifest.permission.CALL_PHONE)== PackageManager.PERMISSION_GRANTED &&
         ContextCompat.checkSelfPermission(MainActivity.this,
         Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED &&
         ContextCompat.checkSelfPermission(MainActivity.this,
         Manifest.permission.ACCESS_NETWORK_STATE)== PackageManager.PERMISSION_GRANTED)
         */
        {

            Toast.makeText(MainActivity.this,"Permission Granted",Toast.LENGTH_LONG).show();


        }else if( ContextCompat.checkSelfPermission(MainActivity.this,

                Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED )
        {
            Toast.makeText(MainActivity.this,"Permission Granted",Toast.LENGTH_LONG).show();
        }else if( ContextCompat.checkSelfPermission(MainActivity.this,

                Manifest.permission.RECORD_AUDIO)== PackageManager.PERMISSION_GRANTED )
        {
            Toast.makeText(MainActivity.this,"Permission Granted",Toast.LENGTH_LONG).show();
        }

        else
        {
            requstStoragePermission();
        }

        //btn = (Button)findViewById(R.id.button);

        /**btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Signup.class);
                startActivity(intent);
            }
        });*/
    }


    private void registerUserAccount(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("REGISTER");
        dialog.setMessage("Please create an account with us");

        LayoutInflater inflater = LayoutInflater.from(this);
        View register_layout = inflater.inflate(R.layout.activity_signup,null);

         txtUsername = register_layout.findViewById(R.id.edtUsername);
         edtEmail = register_layout.findViewById(R.id.edtEmail);
         edtPassword = register_layout.findViewById(R.id.edtPassword);
         edtConfirmpassword = register_layout.findViewById(R.id.edtconfirmsPasswrd);

        checkBox2 = (CheckBox)register_layout.findViewById(R.id.terms);

        dialog.setView(register_layout);


        dialog.setPositiveButton("REGISTER", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {


                if (txtUsername.getText().toString().length() == 0) {
                    txtUsername.setError("Username name not entered");
                    txtUsername.requestFocus();
                }else
                if (!edtEmail.getText().toString().contains("@")) {
                    edtEmail.setError("Enter valid email address");
                    edtEmail.requestFocus();
                }else
                if(edtPassword.getText().toString().length() < 4)
                {
                    edtPassword.setError("Password must have four characters or more");
                    edtPassword.requestFocus();
                }else
                if(edtConfirmpassword.getText().toString().compareTo(edtPassword.getText().toString())  !=0)
                {
                    edtConfirmpassword.setError("The password don't match");
                    edtConfirmpassword.requestFocus();

                }else
                if(checkBox2.isChecked()){


                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                    //nameValuePairs.add(new BasicNameValuePair("firstname",edtFirst.getText().toString()));

                    nameValuePairs.add(new BasicNameValuePair("username", txtUsername.getText().toString()));
                    nameValuePairs.add(new BasicNameValuePair("email", edtEmail.getText().toString()));
                    nameValuePairs.add(new BasicNameValuePair("password", edtPassword.getText().toString()));

                    try {
                        HttpClient httpclient = new DefaultHttpClient();
                        HttpPost httppost = new HttpPost("http://www.yego.africa/Register.php");
                        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                        HttpResponse response = httpclient.execute(httppost);
                        HttpEntity entity = response.getEntity();
                        is = entity.getContent();
                        Log.e("pass 1", "connection success ");
                    } catch (Exception e) {
                        Log.e("Fail 1", e.toString());
                        Toast.makeText(getApplicationContext(), "Connection Error,Please check your internet connection",
                                Toast.LENGTH_LONG).show();
                    }

                    try {
                        BufferedReader reader = new BufferedReader
                                (new InputStreamReader(is, "iso-8859-1"), 8);
                        StringBuilder sb = new StringBuilder();
                        while ((line = reader.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                        is.close();
                        result = sb.toString();
                        Log.e("pass 2", "connection success ");
                    } catch (Exception e) {
                        Log.e("Fail 2", e.toString());
                    }

                    try {
                        JSONObject json_data = new JSONObject(result);

                        String myString = json_data.getString("code");

                        if(myString.equals("1"))
                        {
                            Toast.makeText(MainActivity.this, "Account created", Toast.LENGTH_LONG).show();
                        }else{
                            Toast.makeText(MainActivity.this, "Account was not created", Toast.LENGTH_LONG).show();
                        }



                    } catch (Exception e) {
                        Log.e("Fail 3", e.toString());
                    }

                    //Intent intent = new Intent(this,MainActivity.class);
                    //startActivity(intent);




                }else{
                    Toast.makeText(MainActivity.this,"Please note that you need to accept our terms and conditions first",Toast.LENGTH_LONG).show();
                }

            }
        });


        dialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                dialogInterface.dismiss();

            }
        });

        dialog.show();

    }

    private void requstStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE))
        /**&&
         *  ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
         Manifest.permission.READ_PHONE_STATE)&&
         ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
         Manifest.permission.WRITE_EXTERNAL_STORAGE)&&
         ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
         Manifest.permission.ACCESS_NETWORK_STATE))*/ {

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed so that the app could start")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO,
                                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                            Manifest.permission.ACCESS_NETWORK_STATE}, VOICE_PERMISSION);

                            /**
                             ActivityCompat.requestPermissions(MainActivity.this,
                             new String[]{Manifest.permission.READ_PHONE_STATE},READ_PHONE_PERMISSION);
                             ActivityCompat.requestPermissions(MainActivity.this,
                             new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},WRITE_EXTERNAL_PERMISSION);
                             ActivityCompat.requestPermissions(MainActivity.this,
                             new String[]{Manifest.permission.ACCESS_NETWORK_STATE},ACCESS_NETWORK_PERMISSION);
                             */

                        }
                    })
                    .create().show();


        } else {


            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_NETWORK_STATE}, VOICE_PERMISSION);

        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == VOICE_PERMISSION)
        //requestCode == WRITE_EXTERNAL_PERMISSION||
        // requestCode == ACCESS_NETWORK_PERMISSION)
        {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MainActivity.this, "Permission GRANTED", Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(MainActivity.this, "Permission DENIED", Toast.LENGTH_LONG).show();

            }

        }
    }

    public void login(View view) throws JSONException {


        //Intent intent2 = new Intent(this,WelcomeScreen.class);
        //startActivity(intent2);

        if (edtEmails.getText().toString().length() == 0) {
            edtEmails.setError("Email not correct");
            edtEmails.requestFocus();
 
            //Intent intent2 = new Intent(this,MainActivity.class);
            //startActivity(intent2);

        }else
        if (edtconfirmsPasswrds.getText().toString().length() == 0) {
            edtconfirmsPasswrds.setError("Password not correct");
            edtconfirmsPasswrds.requestFocus();

            //Intent intent2 = new Intent(this,MainActivity.class);
           // startActivity(intent2);


        }else{

            /**progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Signing in");
            progressDialog.setMessage("Please wait...");
            progressDialog.show();*/



            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();


            nameValuePairs.add(new BasicNameValuePair("username", edtEmails.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("pass_word", edtconfirmsPasswrds.getText().toString()));



            try {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost("http://www.yego.africa/maru.php");
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
                Log.e("pass 1", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 1", e.toString());
                Toast.makeText(getApplicationContext(), "Connection Error,Please check your internet connection",
                        Toast.LENGTH_LONG).show();
            }

            try {
                BufferedReader reader = new BufferedReader
                        (new InputStreamReader(is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                result = sb.toString();
                Log.e("pass 2", "connection success ");
            } catch (Exception e) {
                Log.e("Fail 2", e.toString());
            }

            try {
                JSONObject json_data = new JSONObject(result);


                String code = json_data.getString("code");


                if(code.equals("1")){
                    //Toast.makeText(this, code, Toast.LENGTH_LONG).show();
                    user_email= edtEmails.getText().toString();
                    // mprogress.setVisibility(View.VISIBLE);


                    Intent intent2 = new Intent(this,WelcomeScreen.class);
                    startActivity(intent2);
                   // progressDialog.dismiss();

                }else if(code=="0"){
                    if (edtEmails.getText().toString().length() == 0) {
                        edtEmails.setError("Username required");
                        edtEmails.requestFocus();

                    }
                    if (edtconfirmsPasswrds.getText().toString().length() == 0) {
                        edtconfirmsPasswrds.setError("Password required");
                        edtconfirmsPasswrds.requestFocus();

                    }
                    else{
                        Toast.makeText(this, "Incorrect username or Password", Toast.LENGTH_LONG).show();
                    }

                }



            } catch (Exception e) {
                Log.e("Fail 3", e.toString());
            }



        }





    }



    /**public void register(View view)
    {
        Intent intent = new Intent(this,Signup.class);
        //Intent intent = new Intent(this,WelcomeScreen.class);
        startActivity(intent);
    }*/

    public void facebook(View view)
    {

        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com/maruafrica")));

    }
    public void twitter(View view)
    {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/maruafrica")));
    }
    public void instagram(View view)
    {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/maruafrica")));
    }




}
