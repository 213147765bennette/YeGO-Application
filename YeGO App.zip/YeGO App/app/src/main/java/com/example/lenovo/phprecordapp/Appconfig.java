package com.example.lenovo.phprecordapp;

/**
 * Created by Lenovo on 2018-03-19.
 */

public class Appconfig {
    public static boolean activity = false;
}
