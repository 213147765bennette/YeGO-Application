package com.example.lenovo.phprecordapp;

import android.app.Dialog;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Dictionary extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    public MediaRecorder myRecorder;
    ListView myView;
    InputStream is=null;

    ArrayList<SaveToDictionaryModel> myList = new ArrayList<SaveToDictionaryModel>();
    ArrayAdapter<SaveToDictionaryModel> myAdapter;

    String wordToAdd = "";
    String selectedwordclass = "";
    String desc = "";
    private String SERVER_URL = "http://www.yego.africa/";
    String yourword ="";
    String language="";
    String wordclass="";
    String description="";
    String relatedWord ="";

    String result=null;
    String line=null;


    Dialog myDialog;

    String addTolist = "";

    Cursor cursor;
    String voicepath;

    Uploadword uploadword;
    File[] myFiles;
    int pos;
    SaveToDictionaryModel saveToDictionaryModel;

    ArrayList<SaveToDictionaryModel> myModelList;

    ArrayList<String> myWords;


    SaveToDictionaryModel[] list;
    DictionayCustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);

        myView = (ListView)findViewById(R.id.myListView);

       // SaveUserDB saveUserDB = new SaveUserDB(this);

        saveToDictionaryModel = new SaveToDictionaryModel();

        myModelList = new ArrayList<SaveToDictionaryModel>();

       // cursor = saveUserDB.getData();

        /**if(cursor.moveToFirst()) {

            yourword = cursor.getString(1);
            language = cursor.getString(2);
            wordclass = cursor.getString(3);
            description = cursor.getString(4);

            saveToDictionaryModel = new SaveToDictionaryModel();

            saveToDictionaryModel.setWordAdded(yourword);
            saveToDictionaryModel.setLanguage(language);
            saveToDictionaryModel.setWordClass(wordclass);
            saveToDictionaryModel.setDescription(description);

            myModelList.add(saveToDictionaryModel);

            cursor.moveToNext();
        }*/
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();


        //nameValuePairs.add(new BasicNameValuePair("username", edtEmail.getText().toString()));
        //nameValuePairs.add(new BasicNameValuePair("pass_word", edtconfirmsPasswrd.getText().toString()));

        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://www.yego.africa/read.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
            Log.e("pass 1", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 1", e.toString());
            Toast.makeText(getApplicationContext(), "Connection Error,Please check your internet connection!!",
                    Toast.LENGTH_LONG).show();
        }

        try {
            BufferedReader reader = new BufferedReader
                    (new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
            Log.e("pass 2", "connection success ");
        } catch (Exception e) {
            Log.e("Fail 2", e.toString());
        }

        try {
            JSONObject json_data = new JSONObject(result);


            JSONArray jsonMainNode = json_data.optJSONArray("list");
           SaveToDictionaryModel[] saveToDictionaryModel = new SaveToDictionaryModel[jsonMainNode.length()];
            for (int i = 0;i < jsonMainNode.length();i++) {
                JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);

                yourword = jsonChildNode.getString("d_Word");
                description = jsonChildNode.getString("d_Description");
                language = jsonChildNode.getString("d_Language");
                wordclass = jsonChildNode.getString("d_wordClass");
                relatedWord = jsonChildNode.getString("related_words");

               // saveToDictionaryModel = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);


                //saveToDictionaryModel[i] = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);
                //myModelList.add(saveToDictionaryModel[i]);


                //myWords.add(saveToDictionaryModel.getWordAdded());

                //DictionayCustomAdapter adapter = new DictionayCustomAdapter(Dictionary.this,list);
                //myView.setAdapter(adapter);

                //myModelList.add(saveToDictionaryModel);

               // myAdapter = new ArrayAdapter<SaveToDictionaryModel>(this, android.R.layout.simple_list_item_1,myModelList);

                //myView.setAdapter(myAdapter);




                //voicepath = RecordVoice.outputFile;


                /**myView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                        pos = i;

                       // saveToDictionaryModel = new SaveToDictionaryModel(yourword,wordclass,description,language,relatedWord);

                        AlertDialog.Builder builder = new AlertDialog.Builder(Dictionary.this);

                        builder.create();
                        builder.setTitle("The word description");



                        builder.setMessage("Word: "+myModelList.get(i).getWordAdded()+"\nWord class: " +myModelList.get(i).getWordClass()+
                                "\nDescription: "+myModelList.get(i).getDescription()+"\nLanguage: "+myModelList.get(i).getLanguage());

                        builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub


                            }
                        });


                        builder.setPositiveButton("Play Audio", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub

                                String n=myModelList.get(pos).getRelatedWord();

                                 mediaPlayer  = new MediaPlayer();
                                try{


                                    mediaPlayer.setDataSource(SERVER_URL+""+n);
                                    //mediaPlayer.setDataSource(path);
                                    mediaPlayer.prepare();
                                    mediaPlayer.start();


                                    Toast.makeText(getApplicationContext(),"Playing Audio",Toast.LENGTH_LONG).show();





                                }catch (Exception x){}




                            }
                        });

                        AlertDialog alert = builder.create();

                        alert.show();
                    }
                });*/

            }

            adapter  = new DictionayCustomAdapter(Dictionary.this,saveToDictionaryModel);
             //myistview = (ListView)findViewById(R.id.myistview);
            myView.setAdapter(adapter);

            //Toast.makeText(this, first_name+" "+email_profile+" "+last_name, Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.e("Fail 3", e.toString());
        }



       /** if(myModelList.isEmpty())
        {
            Toast.makeText(this,"The dictionary is empty please go back and upload your word to the dictionary first", Toast.LENGTH_LONG).show();

        }*/




}

  /*  @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.welcome_screen,menu);
        MenuItem item = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView)item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }*/



}

